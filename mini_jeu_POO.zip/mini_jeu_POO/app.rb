require 'bundler'
Bundler.require

require_relative 'lib/player'
require_relative 'lib/game'



player1= Player.new('Scorpion')
player2= Player.new('Sub-Zero')

puts player2.name

puts " A ma droite #{player1.name} à ma gauche le terrible #{player2.name}"
puts " Voici l'état de chaque combattant #{player1.name} a #{player1.life_points} et #{player2.name}a #{player2.life_points}"


while player1.life_points >0 && player2.life_points >0
    player2.attacks(player1)
    player1.attacks(player2)
    if player1.life_points <0
        break
    end
    
end


binding.pry
