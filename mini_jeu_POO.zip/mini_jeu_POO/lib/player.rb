class Player
    attr_accessor :name 
   
    
    def initialize(name)
     @name = name
     @life_points = 10
    end

    def life_points
        return @life_points
    end

    def show_state
     puts " #{@name} a #{@life_points} points de vie"
    end

    def gets_damage(damage)
        @damage= damage
        @life_points= @life_points-@damage
        if @life_points < 0
            puts " Le joueur #{@name} est mort"
        end
    end
    
    def attacks(player2)
        puts "Le joueur #{@name} attaque le joueur #{player2.name}"
        damage= compute_damage
        player2.gets_damage(damage)
        puts " il lui inflige #{damage} points de dégats"
    end

    def compute_damage
        return rand(1..6)
      end


end